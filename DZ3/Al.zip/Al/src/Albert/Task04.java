package Albert;


public class Task04 {

    public static void main(String[] args) {
        // для одного пробела используется \f
        System.out.println("Hello\fworld!");

        // для использования четверного пробела (как при помощи клавиши TAB) используется  \t
        System.out.print("Hello\tworld!");


    }

}
