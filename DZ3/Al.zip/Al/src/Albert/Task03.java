package Albert;

public class Task03 {

    public static void main(String[] args)
    {
        // Задача округлить число n до ближайщего целого

        double n=2.49;

        System.out.print(Math.round(n));
    }
}
